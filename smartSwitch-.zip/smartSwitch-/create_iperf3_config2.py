import configparser
import argparse
import sys
import ast

####################################################################################################
"""
get_options
    get user options
    input : argv[1:]
    output: options
"""
def get_options(args=sys.argv[1:]):
    parser = argparse.ArgumentParser(description="Parse user input")
    parser.add_argument("-topo", "--topo", type=str, required=True, help="topology init file")
    parser.add_argument("-t", "--transmit_time", dest ='transmit_time', type=int, default=30, required=False, help="transmit time in iperf3")
    parser.add_argument("-d", "--direct_connection", dest='dc', action='store_const', const=1, default=0, required=False, help="give each client server")
    
    parser.add_argument("-reno", "--R", dest='reno',  type=int, default=0, required=False, help="run with reno CCA")
    parser.add_argument("-vegas","--V", dest='vegas', type=int, default=0, required=False, help="run with vegas CCA")
    parser.add_argument("-bbr",  "--B", dest='bbr',   type=int, default=0, required=False, help="run with bbr CCA")
    parser.add_argument("-cubic","--C", dest='cubic', type=int, default=0, required=False, help="run with cubic CCA")
    
    options = parser.parse_args(args)
    return options

####################################################################################################
"""
create_iperf3_ini : create the iperf3 ini files for topology
    input : topo_init_file , transmit_time (each client transmit time to server), with which CCA we run 
    output: iperf3 ini file for topology1
"""
def create_iperf3_ini(topo_init_file, transmit_time, dc, reno, vegas, bbr, cubic):

    topo_config = configparser.ConfigParser()
    topo_config.read(topo_init_file)
    iperf3_config = configparser.ConfigParser()

    parameters_hash = {}
    server_cmd_hash = {}
    client_cmd_hash = {}
    sc_hash = {}

    print("*** creating iperf3 cfg file for {}, scenario - all clients are sending\n".format(topo_config["parameters"]["name"]))
    iperf3_config["parameters"] = {
        "name": topo_config["parameters"]["name"],
        "transmit_time": transmit_time,
        "direct_connection": dc,
        "Reno" : reno,
        "Vegas": vegas,
        "BBR"  : bbr,
        "cubic": cubic,
    }
    server_ip = topo_config["ips"]["server_base_ip"] + str(100)
    server_base_port = topo_config["ports"]["server_base_port"]
    # Create iperf3 config file for Topo1 and Topo2 (scenario1 - all clients are sending)
    flow_num = int(topo_config["parameters"]["flows_num"])
    error=int(topo_config["parameters"]["flows_error"])
    if dc==0:
        cmd_num = reno+vegas+bbr+cubic
    else:
        bs=int(topo_config["parameters"]["buffer_size"])
        cmd_num = (reno+vegas+bbr+cubic)*bs

    print("******** command num is:"+ str(cmd_num))
    cmd = 0
    cca_list = []
    flows = []

    
    cca_list.append("reno")
    flows.append(reno)
    
    cca_list.append("vegas")
    flows.append(vegas)
    
    cca_list.append("bbr")
    flows.append(bbr)
    
    cca_list.append("cubic")
    flows.append(cubic)


    '''
    # -i for interval time parameter report
    # -s server, -c client
    # -p port to listen (same in server and client)
    #-C set congestion control algorithm'''

    

    base_ip=0
    j=0
    for c in cca_list: 
        for f in range(flows[j]):
            server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
            client_cmd_hash[str(cmd)] = "iperf3 -i 1 -V -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (server_ip, str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(cmd+1+base_ip),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+".log")
           
            cmd=cmd+1
        j=j+1
        base_ip=base_ip+64
            


    sc_hash["1"] = {
        "server_cmds"   : server_cmd_hash,
        "clients_cmds"  : client_cmd_hash
                   }
    iperf3_config["sc"] = sc_hash

    with open("cfg/iperf3.ini", "w") as iperf3_config_file:
        iperf3_config.write(iperf3_config_file)

####################################################################################################
if __name__ == "__main__":
    options = get_options()
    create_iperf3_ini(options.topo, options.transmit_time,options.dc ,options.reno, options.vegas, options.bbr, options.cubic)
