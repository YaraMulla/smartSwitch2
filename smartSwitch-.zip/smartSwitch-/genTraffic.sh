client_0 ethtool -K client_0-eth0 tso off
client_1 ethtool -K client_1-eth0 tso off
client_2 ethtool -K client_2-eth0 tso off
client_3 ethtool -K client_3-eth0 tso off
client_4 ethtool -K client_4-eth0 tso off
client_5 ethtool -K client_5-eth0 tso off
client_6 ethtool -K client_6-eth0 tso off
client_7 ethtool -K client_7-eth0 tso off
client_8 ethtool -K client_8-eth0 tso off
client_9 ethtool -K client_9-eth0 tso off
client_10 ethtool -K client_10-eth0 tso off
client_11 ethtool -K client_11-eth0 tso off
client_12 ethtool -K client_12-eth0 tso off
client_13 ethtool -K client_13-eth0 tso off
client_14 ethtool -K client_14-eth0 tso off
client_15 ethtool -K client_15-eth0 tso off
client_16 ethtool -K client_16-eth0 tso off
client_17 ethtool -K client_17-eth0 tso off
client_18 ethtool -K client_18-eth0 tso off
client_19 ethtool -K client_19-eth0 tso off
client_20 ethtool -K client_20-eth0 tso off
client_21 ethtool -K client_21-eth0 tso off
client_22 ethtool -K client_22-eth0 tso off
client_23 ethtool -K client_23-eth0 tso off
client_24 ethtool -K client_24-eth0 tso off
client_25 ethtool -K client_25-eth0 tso off
client_26 ethtool -K client_26-eth0 tso off
client_27 ethtool -K client_27-eth0 tso off
client_28 ethtool -K client_28-eth0 tso off
client_29 ethtool -K client_29-eth0 tso off
client_30 ethtool -K client_30-eth0 tso off
client_31 ethtool -K client_31-eth0 tso off
client_32 ethtool -K client_32-eth0 tso off
client_33 ethtool -K client_33-eth0 tso off
client_34 ethtool -K client_34-eth0 tso off
client_35 ethtool -K client_35-eth0 tso off
client_36 ethtool -K client_36-eth0 tso off
client_37 ethtool -K client_37-eth0 tso off
client_38 ethtool -K client_38-eth0 tso off
client_39 ethtool -K client_39-eth0 tso off
client_40 ethtool -K client_40-eth0 tso off
client_41 ethtool -K client_41-eth0 tso off
client_42 ethtool -K client_42-eth0 tso off
client_43 ethtool -K client_43-eth0 tso off
client_44 ethtool -K client_44-eth0 tso off
client_45 ethtool -K client_45-eth0 tso off
client_46 ethtool -K client_46-eth0 tso off
client_47 ethtool -K client_47-eth0 tso off
client_48 ethtool -K client_48-eth0 tso off
client_49 ethtool -K client_49-eth0 tso off
client_50 ethtool -K client_50-eth0 tso off
client_51 ethtool -K client_51-eth0 tso off
client_52 ethtool -K client_52-eth0 tso off
client_53 ethtool -K client_53-eth0 tso off
client_54 ethtool -K client_54-eth0 tso off
client_55 ethtool -K client_55-eth0 tso off
client_56 ethtool -K client_56-eth0 tso off
client_57 ethtool -K client_57-eth0 tso off
client_58 ethtool -K client_58-eth0 tso off
client_59 ethtool -K client_59-eth0 tso off
client_60 ethtool -K client_60-eth0 tso off
client_61 ethtool -K client_61-eth0 tso off
client_62 ethtool -K client_62-eth0 tso off
client_63 ethtool -K client_63-eth0 tso off
client_64 ethtool -K client_64-eth0 tso off
client_65 ethtool -K client_65-eth0 tso off
client_66 ethtool -K client_66-eth0 tso off
client_67 ethtool -K client_67-eth0 tso off
client_68 ethtool -K client_68-eth0 tso off
client_69 ethtool -K client_69-eth0 tso off
client_70 ethtool -K client_70-eth0 tso off
client_71 ethtool -K client_71-eth0 tso off
client_72 ethtool -K client_72-eth0 tso off
client_73 ethtool -K client_73-eth0 tso off
client_74 ethtool -K client_74-eth0 tso off
client_75 ethtool -K client_75-eth0 tso off
client_76 ethtool -K client_76-eth0 tso off
client_77 ethtool -K client_77-eth0 tso off
client_78 ethtool -K client_78-eth0 tso off
client_79 ethtool -K client_79-eth0 tso off
client_80 ethtool -K client_80-eth0 tso off
client_81 ethtool -K client_81-eth0 tso off
client_82 ethtool -K client_82-eth0 tso off
client_83 ethtool -K client_83-eth0 tso off
client_84 ethtool -K client_84-eth0 tso off
client_85 ethtool -K client_85-eth0 tso off
client_86 ethtool -K client_86-eth0 tso off
client_87 ethtool -K client_87-eth0 tso off
client_88 ethtool -K client_88-eth0 tso off
client_89 ethtool -K client_89-eth0 tso off
client_90 ethtool -K client_90-eth0 tso off
client_91 ethtool -K client_91-eth0 tso off
client_92 ethtool -K client_92-eth0 tso off
client_93 ethtool -K client_93-eth0 tso off
client_94 ethtool -K client_94-eth0 tso off
client_95 ethtool -K client_95-eth0 tso off
client_96 ethtool -K client_96-eth0 tso off
client_97 ethtool -K client_97-eth0 tso off
client_98 ethtool -K client_98-eth0 tso off
client_99 ethtool -K client_99-eth0 tso off
client_100 ethtool -K client_100-eth0 tso off
client_101 ethtool -K client_101-eth0 tso off
client_102 ethtool -K client_102-eth0 tso off
client_103 ethtool -K client_103-eth0 tso off
client_104 ethtool -K client_104-eth0 tso off
client_105 ethtool -K client_105-eth0 tso off
client_106 ethtool -K client_106-eth0 tso off
client_107 ethtool -K client_107-eth0 tso off
client_108 ethtool -K client_108-eth0 tso off
client_109 ethtool -K client_109-eth0 tso off
client_110 ethtool -K client_110-eth0 tso off
client_111 ethtool -K client_111-eth0 tso off
client_112 ethtool -K client_112-eth0 tso off
client_113 ethtool -K client_113-eth0 tso off
client_114 ethtool -K client_114-eth0 tso off
client_115 ethtool -K client_115-eth0 tso off
client_116 ethtool -K client_116-eth0 tso off
client_117 ethtool -K client_117-eth0 tso off
client_118 ethtool -K client_118-eth0 tso off
client_119 ethtool -K client_119-eth0 tso off
client_120 ethtool -K client_120-eth0 tso off
client_121 ethtool -K client_121-eth0 tso off
client_122 ethtool -K client_122-eth0 tso off
client_123 ethtool -K client_123-eth0 tso off
client_124 ethtool -K client_124-eth0 tso off
client_125 ethtool -K client_125-eth0 tso off
client_126 ethtool -K client_126-eth0 tso off
client_127 ethtool -K client_127-eth0 tso off
client_128 ethtool -K client_128-eth0 tso off
client_129 ethtool -K client_129-eth0 tso off
client_130 ethtool -K client_130-eth0 tso off
client_131 ethtool -K client_131-eth0 tso off
client_132 ethtool -K client_132-eth0 tso off
client_133 ethtool -K client_133-eth0 tso off
client_134 ethtool -K client_134-eth0 tso off
client_135 ethtool -K client_135-eth0 tso off
client_136 ethtool -K client_136-eth0 tso off
client_137 ethtool -K client_137-eth0 tso off
client_138 ethtool -K client_138-eth0 tso off
client_139 ethtool -K client_139-eth0 tso off
client_140 ethtool -K client_140-eth0 tso off
client_141 ethtool -K client_141-eth0 tso off
client_142 ethtool -K client_142-eth0 tso off
client_143 ethtool -K client_143-eth0 tso off
client_144 ethtool -K client_144-eth0 tso off
client_145 ethtool -K client_145-eth0 tso off
client_146 ethtool -K client_146-eth0 tso off
client_147 ethtool -K client_147-eth0 tso off
client_148 ethtool -K client_148-eth0 tso off
client_149 ethtool -K client_149-eth0 tso off
server iperf3 -i 1 -s -p 5001 > server.log &
server iperf3 -i 1 -s -p 5002 > server.log &
server iperf3 -i 1 -s -p 5003 > server.log &
server iperf3 -i 1 -s -p 5004 > server.log &
server iperf3 -i 1 -s -p 5005 > server.log &
server iperf3 -i 1 -s -p 5006 > server.log &
server iperf3 -i 1 -s -p 5007 > server.log &
server iperf3 -i 1 -s -p 5008 > server.log &
server iperf3 -i 1 -s -p 5009 > server.log &
server iperf3 -i 1 -s -p 5010 > server.log &
server iperf3 -i 1 -s -p 5011 > server.log &
server iperf3 -i 1 -s -p 5012 > server.log &
server iperf3 -i 1 -s -p 5013 > server.log &
server iperf3 -i 1 -s -p 5014 > server.log &
server iperf3 -i 1 -s -p 5015 > server.log &
server iperf3 -i 1 -s -p 5016 > server.log &
server iperf3 -i 1 -s -p 5017 > server.log &
server iperf3 -i 1 -s -p 5018 > server.log &
server iperf3 -i 1 -s -p 5019 > server.log &
server iperf3 -i 1 -s -p 5020 > server.log &
server iperf3 -i 1 -s -p 5021 > server.log &
server iperf3 -i 1 -s -p 5022 > server.log &
server iperf3 -i 1 -s -p 5023 > server.log &
server iperf3 -i 1 -s -p 5024 > server.log &
server iperf3 -i 1 -s -p 5025 > server.log &
server iperf3 -i 1 -s -p 5026 > server.log &
server iperf3 -i 1 -s -p 5027 > server.log &
server iperf3 -i 1 -s -p 5028 > server.log &
server iperf3 -i 1 -s -p 5029 > server.log &
server iperf3 -i 1 -s -p 5030 > server.log &
server iperf3 -i 1 -s -p 5031 > server.log &
server iperf3 -i 1 -s -p 5032 > server.log &
server iperf3 -i 1 -s -p 5033 > server.log &
server iperf3 -i 1 -s -p 5034 > server.log &
server iperf3 -i 1 -s -p 5035 > server.log &
server iperf3 -i 1 -s -p 5036 > server.log &
server iperf3 -i 1 -s -p 5037 > server.log &
server iperf3 -i 1 -s -p 5038 > server.log &
server iperf3 -i 1 -s -p 5039 > server.log &
server iperf3 -i 1 -s -p 5040 > server.log &
server iperf3 -i 1 -s -p 5041 > server.log &
server iperf3 -i 1 -s -p 5042 > server.log &
server iperf3 -i 1 -s -p 5043 > server.log &
server iperf3 -i 1 -s -p 5044 > server.log &
server iperf3 -i 1 -s -p 5045 > server.log &
server iperf3 -i 1 -s -p 5046 > server.log &
server iperf3 -i 1 -s -p 5047 > server.log &
server iperf3 -i 1 -s -p 5048 > server.log &
server iperf3 -i 1 -s -p 5049 > server.log &
server iperf3 -i 1 -s -p 5050 > server.log &
server iperf3 -i 1 -s -p 5051 > server.log &
server iperf3 -i 1 -s -p 5052 > server.log &
server iperf3 -i 1 -s -p 5053 > server.log &
server iperf3 -i 1 -s -p 5054 > server.log &
server iperf3 -i 1 -s -p 5055 > server.log &
server iperf3 -i 1 -s -p 5056 > server.log &
server iperf3 -i 1 -s -p 5057 > server.log &
server iperf3 -i 1 -s -p 5058 > server.log &
server iperf3 -i 1 -s -p 5059 > server.log &
server iperf3 -i 1 -s -p 5060 > server.log &
server iperf3 -i 1 -s -p 5061 > server.log &
server iperf3 -i 1 -s -p 5062 > server.log &
server iperf3 -i 1 -s -p 5063 > server.log &
server iperf3 -i 1 -s -p 5064 > server.log &
server iperf3 -i 1 -s -p 5065 > server.log &
server iperf3 -i 1 -s -p 5066 > server.log &
server iperf3 -i 1 -s -p 5067 > server.log &
server iperf3 -i 1 -s -p 5068 > server.log &
server iperf3 -i 1 -s -p 5069 > server.log &
server iperf3 -i 1 -s -p 5070 > server.log &
server iperf3 -i 1 -s -p 5071 > server.log &
server iperf3 -i 1 -s -p 5072 > server.log &
server iperf3 -i 1 -s -p 5073 > server.log &
server iperf3 -i 1 -s -p 5074 > server.log &
server iperf3 -i 1 -s -p 5075 > server.log &
server iperf3 -i 1 -s -p 5076 > server.log &
server iperf3 -i 1 -s -p 5077 > server.log &
server iperf3 -i 1 -s -p 5078 > server.log &
server iperf3 -i 1 -s -p 5079 > server.log &
server iperf3 -i 1 -s -p 5080 > server.log &
server iperf3 -i 1 -s -p 5081 > server.log &
server iperf3 -i 1 -s -p 5082 > server.log &
server iperf3 -i 1 -s -p 5083 > server.log &
server iperf3 -i 1 -s -p 5084 > server.log &
server iperf3 -i 1 -s -p 5085 > server.log &
server iperf3 -i 1 -s -p 5086 > server.log &
server iperf3 -i 1 -s -p 5087 > server.log &
server iperf3 -i 1 -s -p 5088 > server.log &
server iperf3 -i 1 -s -p 5089 > server.log &
server iperf3 -i 1 -s -p 5090 > server.log &
server iperf3 -i 1 -s -p 5091 > server.log &
server iperf3 -i 1 -s -p 5092 > server.log &
server iperf3 -i 1 -s -p 5093 > server.log &
server iperf3 -i 1 -s -p 5094 > server.log &
server iperf3 -i 1 -s -p 5095 > server.log &
server iperf3 -i 1 -s -p 5096 > server.log &
server iperf3 -i 1 -s -p 5097 > server.log &
server iperf3 -i 1 -s -p 5098 > server.log &
server iperf3 -i 1 -s -p 5099 > server.log &
server iperf3 -i 1 -s -p 5100 > server.log &
server iperf3 -i 1 -s -p 5101 > server.log &
server iperf3 -i 1 -s -p 5102 > server.log &
server iperf3 -i 1 -s -p 5103 > server.log &
server iperf3 -i 1 -s -p 5104 > server.log &
server iperf3 -i 1 -s -p 5105 > server.log &
server iperf3 -i 1 -s -p 5106 > server.log &
server iperf3 -i 1 -s -p 5107 > server.log &
server iperf3 -i 1 -s -p 5108 > server.log &
server iperf3 -i 1 -s -p 5109 > server.log &
server iperf3 -i 1 -s -p 5110 > server.log &
server iperf3 -i 1 -s -p 5111 > server.log &
server iperf3 -i 1 -s -p 5112 > server.log &
server iperf3 -i 1 -s -p 5113 > server.log &
server iperf3 -i 1 -s -p 5114 > server.log &
server iperf3 -i 1 -s -p 5115 > server.log &
server iperf3 -i 1 -s -p 5116 > server.log &
server iperf3 -i 1 -s -p 5117 > server.log &
server iperf3 -i 1 -s -p 5118 > server.log &
server iperf3 -i 1 -s -p 5119 > server.log &
server iperf3 -i 1 -s -p 5120 > server.log &
server iperf3 -i 1 -s -p 5121 > server.log &
server iperf3 -i 1 -s -p 5122 > server.log &
server iperf3 -i 1 -s -p 5123 > server.log &
server iperf3 -i 1 -s -p 5124 > server.log &
server iperf3 -i 1 -s -p 5125 > server.log &
server iperf3 -i 1 -s -p 5126 > server.log &
server iperf3 -i 1 -s -p 5127 > server.log &
server iperf3 -i 1 -s -p 5128 > server.log &
server iperf3 -i 1 -s -p 5129 > server.log &
server iperf3 -i 1 -s -p 5130 > server.log &
server iperf3 -i 1 -s -p 5131 > server.log &
server iperf3 -i 1 -s -p 5132 > server.log &
server iperf3 -i 1 -s -p 5133 > server.log &
server iperf3 -i 1 -s -p 5134 > server.log &
server iperf3 -i 1 -s -p 5135 > server.log &
server iperf3 -i 1 -s -p 5136 > server.log &
server iperf3 -i 1 -s -p 5137 > server.log &
server iperf3 -i 1 -s -p 5138 > server.log &
server iperf3 -i 1 -s -p 5139 > server.log &
server iperf3 -i 1 -s -p 5140 > server.log &
server iperf3 -i 1 -s -p 5141 > server.log &
server iperf3 -i 1 -s -p 5142 > server.log &
server iperf3 -i 1 -s -p 5143 > server.log &
server iperf3 -i 1 -s -p 5144 > server.log &
server iperf3 -i 1 -s -p 5145 > server.log &
server iperf3 -i 1 -s -p 5146 > server.log &
server iperf3 -i 1 -s -p 5147 > server.log &
server iperf3 -i 1 -s -p 5148 > server.log &
server iperf3 -i 1 -s -p 5149 > server.log &
server iperf3 -i 1 -s -p 5150 > server.log &
client_0 iperf3 -i 1 -V -c 192.168.15.100 -p 5001 -C reno -t 60 -B 192.168.8.1 --cport 7001 > client0_reno.log &
client_1 iperf3 -i 1 -V -c 192.168.15.100 -p 5002 -C reno -t 60 -B 192.168.8.2 --cport 7002 > client1_reno.log &
client_2 iperf3 -i 1 -V -c 192.168.15.100 -p 5003 -C reno -t 60 -B 192.168.8.3 --cport 7003 > client2_reno.log &
client_3 iperf3 -i 1 -V -c 192.168.15.100 -p 5004 -C reno -t 60 -B 192.168.8.4 --cport 7004 > client3_reno.log &
client_4 iperf3 -i 1 -V -c 192.168.15.100 -p 5005 -C reno -t 60 -B 192.168.8.5 --cport 7005 > client4_reno.log &
client_5 iperf3 -i 1 -V -c 192.168.15.100 -p 5006 -C reno -t 60 -B 192.168.8.6 --cport 7006 > client5_reno.log &
client_6 iperf3 -i 1 -V -c 192.168.15.100 -p 5007 -C reno -t 60 -B 192.168.8.7 --cport 7007 > client6_reno.log &
client_7 iperf3 -i 1 -V -c 192.168.15.100 -p 5008 -C reno -t 60 -B 192.168.8.8 --cport 7008 > client7_reno.log &
client_8 iperf3 -i 1 -V -c 192.168.15.100 -p 5009 -C reno -t 60 -B 192.168.8.9 --cport 7009 > client8_reno.log &
client_9 iperf3 -i 1 -V -c 192.168.15.100 -p 5010 -C reno -t 60 -B 192.168.8.10 --cport 7010 > client9_reno.log &
client_10 iperf3 -i 1 -V -c 192.168.15.100 -p 5011 -C reno -t 60 -B 192.168.8.11 --cport 7011 > client10_reno.log &
client_11 iperf3 -i 1 -V -c 192.168.15.100 -p 5012 -C reno -t 60 -B 192.168.8.12 --cport 7012 > client11_reno.log &
client_12 iperf3 -i 1 -V -c 192.168.15.100 -p 5013 -C reno -t 60 -B 192.168.8.13 --cport 7013 > client12_reno.log &
client_13 iperf3 -i 1 -V -c 192.168.15.100 -p 5014 -C reno -t 60 -B 192.168.8.14 --cport 7014 > client13_reno.log &
client_14 iperf3 -i 1 -V -c 192.168.15.100 -p 5015 -C reno -t 60 -B 192.168.8.15 --cport 7015 > client14_reno.log &
client_15 iperf3 -i 1 -V -c 192.168.15.100 -p 5016 -C reno -t 60 -B 192.168.8.16 --cport 7016 > client15_reno.log &
client_16 iperf3 -i 1 -V -c 192.168.15.100 -p 5017 -C reno -t 60 -B 192.168.8.17 --cport 7017 > client16_reno.log &
client_17 iperf3 -i 1 -V -c 192.168.15.100 -p 5018 -C reno -t 60 -B 192.168.8.18 --cport 7018 > client17_reno.log &
client_18 iperf3 -i 1 -V -c 192.168.15.100 -p 5019 -C reno -t 60 -B 192.168.8.19 --cport 7019 > client18_reno.log &
client_19 iperf3 -i 1 -V -c 192.168.15.100 -p 5020 -C reno -t 60 -B 192.168.8.20 --cport 7020 > client19_reno.log &
client_20 iperf3 -i 1 -V -c 192.168.15.100 -p 5021 -C reno -t 60 -B 192.168.8.21 --cport 7021 > client20_reno.log &
client_21 iperf3 -i 1 -V -c 192.168.15.100 -p 5022 -C reno -t 60 -B 192.168.8.22 --cport 7022 > client21_reno.log &
client_22 iperf3 -i 1 -V -c 192.168.15.100 -p 5023 -C reno -t 60 -B 192.168.8.23 --cport 7023 > client22_reno.log &
client_23 iperf3 -i 1 -V -c 192.168.15.100 -p 5024 -C reno -t 60 -B 192.168.8.24 --cport 7024 > client23_reno.log &
client_24 iperf3 -i 1 -V -c 192.168.15.100 -p 5025 -C reno -t 60 -B 192.168.8.25 --cport 7025 > client24_reno.log &
client_25 iperf3 -i 1 -V -c 192.168.15.100 -p 5026 -C reno -t 60 -B 192.168.8.26 --cport 7026 > client25_reno.log &
client_26 iperf3 -i 1 -V -c 192.168.15.100 -p 5027 -C reno -t 60 -B 192.168.8.27 --cport 7027 > client26_reno.log &
client_27 iperf3 -i 1 -V -c 192.168.15.100 -p 5028 -C reno -t 60 -B 192.168.8.28 --cport 7028 > client27_reno.log &
client_28 iperf3 -i 1 -V -c 192.168.15.100 -p 5029 -C reno -t 60 -B 192.168.8.29 --cport 7029 > client28_reno.log &
client_29 iperf3 -i 1 -V -c 192.168.15.100 -p 5030 -C reno -t 60 -B 192.168.8.30 --cport 7030 > client29_reno.log &
client_30 iperf3 -i 1 -V -c 192.168.15.100 -p 5031 -C reno -t 60 -B 192.168.8.31 --cport 7031 > client30_reno.log &
client_31 iperf3 -i 1 -V -c 192.168.15.100 -p 5032 -C reno -t 60 -B 192.168.8.32 --cport 7032 > client31_reno.log &
client_32 iperf3 -i 1 -V -c 192.168.15.100 -p 5033 -C reno -t 60 -B 192.168.8.33 --cport 7033 > client32_reno.log &
client_33 iperf3 -i 1 -V -c 192.168.15.100 -p 5034 -C reno -t 60 -B 192.168.8.34 --cport 7034 > client33_reno.log &
client_34 iperf3 -i 1 -V -c 192.168.15.100 -p 5035 -C reno -t 60 -B 192.168.8.35 --cport 7035 > client34_reno.log &
client_35 iperf3 -i 1 -V -c 192.168.15.100 -p 5036 -C reno -t 60 -B 192.168.8.36 --cport 7036 > client35_reno.log &
client_36 iperf3 -i 1 -V -c 192.168.15.100 -p 5037 -C reno -t 60 -B 192.168.8.37 --cport 7037 > client36_reno.log &
client_37 iperf3 -i 1 -V -c 192.168.15.100 -p 5038 -C reno -t 60 -B 192.168.8.38 --cport 7038 > client37_reno.log &
client_38 iperf3 -i 1 -V -c 192.168.15.100 -p 5039 -C reno -t 60 -B 192.168.8.39 --cport 7039 > client38_reno.log &
client_39 iperf3 -i 1 -V -c 192.168.15.100 -p 5040 -C reno -t 60 -B 192.168.8.40 --cport 7040 > client39_reno.log &
client_40 iperf3 -i 1 -V -c 192.168.15.100 -p 5041 -C reno -t 60 -B 192.168.8.41 --cport 7041 > client40_reno.log &
client_41 iperf3 -i 1 -V -c 192.168.15.100 -p 5042 -C reno -t 60 -B 192.168.8.42 --cport 7042 > client41_reno.log &
client_42 iperf3 -i 1 -V -c 192.168.15.100 -p 5043 -C reno -t 60 -B 192.168.8.43 --cport 7043 > client42_reno.log &
client_43 iperf3 -i 1 -V -c 192.168.15.100 -p 5044 -C reno -t 60 -B 192.168.8.44 --cport 7044 > client43_reno.log &
client_44 iperf3 -i 1 -V -c 192.168.15.100 -p 5045 -C reno -t 60 -B 192.168.8.45 --cport 7045 > client44_reno.log &
client_45 iperf3 -i 1 -V -c 192.168.15.100 -p 5046 -C reno -t 60 -B 192.168.8.46 --cport 7046 > client45_reno.log &
client_46 iperf3 -i 1 -V -c 192.168.15.100 -p 5047 -C reno -t 60 -B 192.168.8.47 --cport 7047 > client46_reno.log &
client_47 iperf3 -i 1 -V -c 192.168.15.100 -p 5048 -C reno -t 60 -B 192.168.8.48 --cport 7048 > client47_reno.log &
client_48 iperf3 -i 1 -V -c 192.168.15.100 -p 5049 -C reno -t 60 -B 192.168.8.49 --cport 7049 > client48_reno.log &
client_49 iperf3 -i 1 -V -c 192.168.15.100 -p 5050 -C reno -t 60 -B 192.168.8.50 --cport 7050 > client49_reno.log &
client_50 iperf3 -i 1 -V -c 192.168.15.100 -p 5051 -C cubic -t 60 -B 192.168.10.51 --cport 7051 > client50_cubic.log &
client_51 iperf3 -i 1 -V -c 192.168.15.100 -p 5052 -C cubic -t 60 -B 192.168.10.52 --cport 7052 > client51_cubic.log &
client_52 iperf3 -i 1 -V -c 192.168.15.100 -p 5053 -C cubic -t 60 -B 192.168.10.53 --cport 7053 > client52_cubic.log &
client_53 iperf3 -i 1 -V -c 192.168.15.100 -p 5054 -C cubic -t 60 -B 192.168.10.54 --cport 7054 > client53_cubic.log &
client_54 iperf3 -i 1 -V -c 192.168.15.100 -p 5055 -C cubic -t 60 -B 192.168.10.55 --cport 7055 > client54_cubic.log &
client_55 iperf3 -i 1 -V -c 192.168.15.100 -p 5056 -C cubic -t 60 -B 192.168.10.56 --cport 7056 > client55_cubic.log &
client_56 iperf3 -i 1 -V -c 192.168.15.100 -p 5057 -C cubic -t 60 -B 192.168.10.57 --cport 7057 > client56_cubic.log &
client_57 iperf3 -i 1 -V -c 192.168.15.100 -p 5058 -C cubic -t 60 -B 192.168.10.58 --cport 7058 > client57_cubic.log &
client_58 iperf3 -i 1 -V -c 192.168.15.100 -p 5059 -C cubic -t 60 -B 192.168.10.59 --cport 7059 > client58_cubic.log &
client_59 iperf3 -i 1 -V -c 192.168.15.100 -p 5060 -C cubic -t 60 -B 192.168.10.60 --cport 7060 > client59_cubic.log &
client_60 iperf3 -i 1 -V -c 192.168.15.100 -p 5061 -C cubic -t 60 -B 192.168.10.61 --cport 7061 > client60_cubic.log &
client_61 iperf3 -i 1 -V -c 192.168.15.100 -p 5062 -C cubic -t 60 -B 192.168.10.62 --cport 7062 > client61_cubic.log &
client_62 iperf3 -i 1 -V -c 192.168.15.100 -p 5063 -C cubic -t 60 -B 192.168.10.63 --cport 7063 > client62_cubic.log &
client_63 iperf3 -i 1 -V -c 192.168.15.100 -p 5064 -C cubic -t 60 -B 192.168.10.64 --cport 7064 > client63_cubic.log &
client_64 iperf3 -i 1 -V -c 192.168.15.100 -p 5065 -C cubic -t 60 -B 192.168.10.65 --cport 7065 > client64_cubic.log &
client_65 iperf3 -i 1 -V -c 192.168.15.100 -p 5066 -C cubic -t 60 -B 192.168.10.66 --cport 7066 > client65_cubic.log &
client_66 iperf3 -i 1 -V -c 192.168.15.100 -p 5067 -C cubic -t 60 -B 192.168.10.67 --cport 7067 > client66_cubic.log &
client_67 iperf3 -i 1 -V -c 192.168.15.100 -p 5068 -C cubic -t 60 -B 192.168.10.68 --cport 7068 > client67_cubic.log &
client_68 iperf3 -i 1 -V -c 192.168.15.100 -p 5069 -C cubic -t 60 -B 192.168.10.69 --cport 7069 > client68_cubic.log &
client_69 iperf3 -i 1 -V -c 192.168.15.100 -p 5070 -C cubic -t 60 -B 192.168.10.70 --cport 7070 > client69_cubic.log &
client_70 iperf3 -i 1 -V -c 192.168.15.100 -p 5071 -C cubic -t 60 -B 192.168.10.71 --cport 7071 > client70_cubic.log &
client_71 iperf3 -i 1 -V -c 192.168.15.100 -p 5072 -C cubic -t 60 -B 192.168.10.72 --cport 7072 > client71_cubic.log &
client_72 iperf3 -i 1 -V -c 192.168.15.100 -p 5073 -C cubic -t 60 -B 192.168.10.73 --cport 7073 > client72_cubic.log &
client_73 iperf3 -i 1 -V -c 192.168.15.100 -p 5074 -C cubic -t 60 -B 192.168.10.74 --cport 7074 > client73_cubic.log &
client_74 iperf3 -i 1 -V -c 192.168.15.100 -p 5075 -C cubic -t 60 -B 192.168.10.75 --cport 7075 > client74_cubic.log &
client_75 iperf3 -i 1 -V -c 192.168.15.100 -p 5076 -C cubic -t 60 -B 192.168.10.76 --cport 7076 > client75_cubic.log &
client_76 iperf3 -i 1 -V -c 192.168.15.100 -p 5077 -C cubic -t 60 -B 192.168.10.77 --cport 7077 > client76_cubic.log &
client_77 iperf3 -i 1 -V -c 192.168.15.100 -p 5078 -C cubic -t 60 -B 192.168.10.78 --cport 7078 > client77_cubic.log &
client_78 iperf3 -i 1 -V -c 192.168.15.100 -p 5079 -C cubic -t 60 -B 192.168.10.79 --cport 7079 > client78_cubic.log &
client_79 iperf3 -i 1 -V -c 192.168.15.100 -p 5080 -C cubic -t 60 -B 192.168.10.80 --cport 7080 > client79_cubic.log &
client_80 iperf3 -i 1 -V -c 192.168.15.100 -p 5081 -C cubic -t 60 -B 192.168.10.81 --cport 7081 > client80_cubic.log &
client_81 iperf3 -i 1 -V -c 192.168.15.100 -p 5082 -C cubic -t 60 -B 192.168.10.82 --cport 7082 > client81_cubic.log &
client_82 iperf3 -i 1 -V -c 192.168.15.100 -p 5083 -C cubic -t 60 -B 192.168.10.83 --cport 7083 > client82_cubic.log &
client_83 iperf3 -i 1 -V -c 192.168.15.100 -p 5084 -C cubic -t 60 -B 192.168.10.84 --cport 7084 > client83_cubic.log &
client_84 iperf3 -i 1 -V -c 192.168.15.100 -p 5085 -C cubic -t 60 -B 192.168.10.85 --cport 7085 > client84_cubic.log &
client_85 iperf3 -i 1 -V -c 192.168.15.100 -p 5086 -C cubic -t 60 -B 192.168.10.86 --cport 7086 > client85_cubic.log &
client_86 iperf3 -i 1 -V -c 192.168.15.100 -p 5087 -C cubic -t 60 -B 192.168.10.87 --cport 7087 > client86_cubic.log &
client_87 iperf3 -i 1 -V -c 192.168.15.100 -p 5088 -C cubic -t 60 -B 192.168.10.88 --cport 7088 > client87_cubic.log &
client_88 iperf3 -i 1 -V -c 192.168.15.100 -p 5089 -C cubic -t 60 -B 192.168.10.89 --cport 7089 > client88_cubic.log &
client_89 iperf3 -i 1 -V -c 192.168.15.100 -p 5090 -C cubic -t 60 -B 192.168.10.90 --cport 7090 > client89_cubic.log &
client_90 iperf3 -i 1 -V -c 192.168.15.100 -p 5091 -C cubic -t 60 -B 192.168.10.91 --cport 7091 > client90_cubic.log &
client_91 iperf3 -i 1 -V -c 192.168.15.100 -p 5092 -C cubic -t 60 -B 192.168.10.92 --cport 7092 > client91_cubic.log &
client_92 iperf3 -i 1 -V -c 192.168.15.100 -p 5093 -C cubic -t 60 -B 192.168.10.93 --cport 7093 > client92_cubic.log &
client_93 iperf3 -i 1 -V -c 192.168.15.100 -p 5094 -C cubic -t 60 -B 192.168.10.94 --cport 7094 > client93_cubic.log &
client_94 iperf3 -i 1 -V -c 192.168.15.100 -p 5095 -C cubic -t 60 -B 192.168.10.95 --cport 7095 > client94_cubic.log &
client_95 iperf3 -i 1 -V -c 192.168.15.100 -p 5096 -C cubic -t 60 -B 192.168.10.96 --cport 7096 > client95_cubic.log &
client_96 iperf3 -i 1 -V -c 192.168.15.100 -p 5097 -C cubic -t 60 -B 192.168.10.97 --cport 7097 > client96_cubic.log &
client_97 iperf3 -i 1 -V -c 192.168.15.100 -p 5098 -C cubic -t 60 -B 192.168.10.98 --cport 7098 > client97_cubic.log &
client_98 iperf3 -i 1 -V -c 192.168.15.100 -p 5099 -C cubic -t 60 -B 192.168.10.99 --cport 7099 > client98_cubic.log &
client_99 iperf3 -i 1 -V -c 192.168.15.100 -p 5100 -C cubic -t 60 -B 192.168.10.100 --cport 7100 > client99_cubic.log &
client_100 iperf3 -i 1 -V -c 192.168.15.100 -p 5101 -C bbr -t 60 -B 192.168.14.101 --cport 7101 > client100_bbr.log &
client_101 iperf3 -i 1 -V -c 192.168.15.100 -p 5102 -C bbr -t 60 -B 192.168.14.102 --cport 7102 > client101_bbr.log &
client_102 iperf3 -i 1 -V -c 192.168.15.100 -p 5103 -C bbr -t 60 -B 192.168.14.103 --cport 7103 > client102_bbr.log &
client_103 iperf3 -i 1 -V -c 192.168.15.100 -p 5104 -C bbr -t 60 -B 192.168.14.104 --cport 7104 > client103_bbr.log &
client_104 iperf3 -i 1 -V -c 192.168.15.100 -p 5105 -C bbr -t 60 -B 192.168.14.105 --cport 7105 > client104_bbr.log &
client_105 iperf3 -i 1 -V -c 192.168.15.100 -p 5106 -C bbr -t 60 -B 192.168.14.106 --cport 7106 > client105_bbr.log &
client_106 iperf3 -i 1 -V -c 192.168.15.100 -p 5107 -C bbr -t 60 -B 192.168.14.107 --cport 7107 > client106_bbr.log &
client_107 iperf3 -i 1 -V -c 192.168.15.100 -p 5108 -C bbr -t 60 -B 192.168.14.108 --cport 7108 > client107_bbr.log &
client_108 iperf3 -i 1 -V -c 192.168.15.100 -p 5109 -C bbr -t 60 -B 192.168.14.109 --cport 7109 > client108_bbr.log &
client_109 iperf3 -i 1 -V -c 192.168.15.100 -p 5110 -C bbr -t 60 -B 192.168.14.110 --cport 7110 > client109_bbr.log &
client_110 iperf3 -i 1 -V -c 192.168.15.100 -p 5111 -C bbr -t 60 -B 192.168.14.111 --cport 7111 > client110_bbr.log &
client_111 iperf3 -i 1 -V -c 192.168.15.100 -p 5112 -C bbr -t 60 -B 192.168.14.112 --cport 7112 > client111_bbr.log &
client_112 iperf3 -i 1 -V -c 192.168.15.100 -p 5113 -C bbr -t 60 -B 192.168.14.113 --cport 7113 > client112_bbr.log &
client_113 iperf3 -i 1 -V -c 192.168.15.100 -p 5114 -C bbr -t 60 -B 192.168.14.114 --cport 7114 > client113_bbr.log &
client_114 iperf3 -i 1 -V -c 192.168.15.100 -p 5115 -C bbr -t 60 -B 192.168.14.115 --cport 7115 > client114_bbr.log &
client_115 iperf3 -i 1 -V -c 192.168.15.100 -p 5116 -C bbr -t 60 -B 192.168.14.116 --cport 7116 > client115_bbr.log &
client_116 iperf3 -i 1 -V -c 192.168.15.100 -p 5117 -C bbr -t 60 -B 192.168.14.117 --cport 7117 > client116_bbr.log &
client_117 iperf3 -i 1 -V -c 192.168.15.100 -p 5118 -C bbr -t 60 -B 192.168.14.118 --cport 7118 > client117_bbr.log &
client_118 iperf3 -i 1 -V -c 192.168.15.100 -p 5119 -C bbr -t 60 -B 192.168.14.119 --cport 7119 > client118_bbr.log &
client_119 iperf3 -i 1 -V -c 192.168.15.100 -p 5120 -C bbr -t 60 -B 192.168.14.120 --cport 7120 > client119_bbr.log &
client_120 iperf3 -i 1 -V -c 192.168.15.100 -p 5121 -C bbr -t 60 -B 192.168.14.121 --cport 7121 > client120_bbr.log &
client_121 iperf3 -i 1 -V -c 192.168.15.100 -p 5122 -C bbr -t 60 -B 192.168.14.122 --cport 7122 > client121_bbr.log &
client_122 iperf3 -i 1 -V -c 192.168.15.100 -p 5123 -C bbr -t 60 -B 192.168.14.123 --cport 7123 > client122_bbr.log &
client_123 iperf3 -i 1 -V -c 192.168.15.100 -p 5124 -C bbr -t 60 -B 192.168.14.124 --cport 7124 > client123_bbr.log &
client_124 iperf3 -i 1 -V -c 192.168.15.100 -p 5125 -C bbr -t 60 -B 192.168.14.125 --cport 7125 > client124_bbr.log &
client_125 iperf3 -i 1 -V -c 192.168.15.100 -p 5126 -C bbr -t 60 -B 192.168.14.126 --cport 7126 > client125_bbr.log &
client_126 iperf3 -i 1 -V -c 192.168.15.100 -p 5127 -C bbr -t 60 -B 192.168.14.127 --cport 7127 > client126_bbr.log &
client_127 iperf3 -i 1 -V -c 192.168.15.100 -p 5128 -C bbr -t 60 -B 192.168.14.128 --cport 7128 > client127_bbr.log &
client_128 iperf3 -i 1 -V -c 192.168.15.100 -p 5129 -C bbr -t 60 -B 192.168.14.129 --cport 7129 > client128_bbr.log &
client_129 iperf3 -i 1 -V -c 192.168.15.100 -p 5130 -C bbr -t 60 -B 192.168.14.130 --cport 7130 > client129_bbr.log &
client_130 iperf3 -i 1 -V -c 192.168.15.100 -p 5131 -C bbr -t 60 -B 192.168.14.131 --cport 7131 > client130_bbr.log &
client_131 iperf3 -i 1 -V -c 192.168.15.100 -p 5132 -C bbr -t 60 -B 192.168.14.132 --cport 7132 > client131_bbr.log &
client_132 iperf3 -i 1 -V -c 192.168.15.100 -p 5133 -C bbr -t 60 -B 192.168.14.133 --cport 7133 > client132_bbr.log &
client_133 iperf3 -i 1 -V -c 192.168.15.100 -p 5134 -C bbr -t 60 -B 192.168.14.134 --cport 7134 > client133_bbr.log &
client_134 iperf3 -i 1 -V -c 192.168.15.100 -p 5135 -C bbr -t 60 -B 192.168.14.135 --cport 7135 > client134_bbr.log &
client_135 iperf3 -i 1 -V -c 192.168.15.100 -p 5136 -C bbr -t 60 -B 192.168.14.136 --cport 7136 > client135_bbr.log &
client_136 iperf3 -i 1 -V -c 192.168.15.100 -p 5137 -C bbr -t 60 -B 192.168.14.137 --cport 7137 > client136_bbr.log &
client_137 iperf3 -i 1 -V -c 192.168.15.100 -p 5138 -C bbr -t 60 -B 192.168.14.138 --cport 7138 > client137_bbr.log &
client_138 iperf3 -i 1 -V -c 192.168.15.100 -p 5139 -C bbr -t 60 -B 192.168.14.139 --cport 7139 > client138_bbr.log &
client_139 iperf3 -i 1 -V -c 192.168.15.100 -p 5140 -C bbr -t 60 -B 192.168.14.140 --cport 7140 > client139_bbr.log &
client_140 iperf3 -i 1 -V -c 192.168.15.100 -p 5141 -C bbr -t 60 -B 192.168.14.141 --cport 7141 > client140_bbr.log &
client_141 iperf3 -i 1 -V -c 192.168.15.100 -p 5142 -C bbr -t 60 -B 192.168.14.142 --cport 7142 > client141_bbr.log &
client_142 iperf3 -i 1 -V -c 192.168.15.100 -p 5143 -C bbr -t 60 -B 192.168.14.143 --cport 7143 > client142_bbr.log &
client_143 iperf3 -i 1 -V -c 192.168.15.100 -p 5144 -C bbr -t 60 -B 192.168.14.144 --cport 7144 > client143_bbr.log &
client_144 iperf3 -i 1 -V -c 192.168.15.100 -p 5145 -C bbr -t 60 -B 192.168.14.145 --cport 7145 > client144_bbr.log &
client_145 iperf3 -i 1 -V -c 192.168.15.100 -p 5146 -C bbr -t 60 -B 192.168.14.146 --cport 7146 > client145_bbr.log &
client_146 iperf3 -i 1 -V -c 192.168.15.100 -p 5147 -C bbr -t 60 -B 192.168.14.147 --cport 7147 > client146_bbr.log &
client_147 iperf3 -i 1 -V -c 192.168.15.100 -p 5148 -C bbr -t 60 -B 192.168.14.148 --cport 7148 > client147_bbr.log &
client_148 iperf3 -i 1 -V -c 192.168.15.100 -p 5149 -C bbr -t 60 -B 192.168.14.149 --cport 7149 > client148_bbr.log &
client_149 iperf3 -i 1 -V -c 192.168.15.100 -p 5150 -C bbr -t 60 -B 192.168.14.150 --cport 7150 > client149_bbr.log &
