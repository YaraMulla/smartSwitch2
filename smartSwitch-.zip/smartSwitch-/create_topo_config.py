import configparser
import sys
import argparse

####################################################################################################
"""
get_options
    get user options
    input : argv[1:]
    output: options
"""
def get_options(args=sys.argv[1:]):
    parser = argparse.ArgumentParser(description="Parse user input")
    parser.add_argument('-i', '--isolation', dest='isolution', help='isolated algo or together',              default=0, required=False,type=int)
    parser.add_argument('-f', '--flows',     dest='flow_num',  help='number of flows to be add for each CCA', default=2, required=False,type=int)
    parser.add_argument("-e","--error", dest='error', type=int, default=0, required=False, help="prediction error in CCA")
    #parser.add_argument('-c', '--CCA',       dest='cca_num',   help='number of different CCA',                default=1, required=False,type=int)
    parser.add_argument('-b', '--BW',        dest='total_bw',  help='bottleneck bandwidth ',                  default=0.143, required=False,type=int)
    parser.add_argument('-tu', '--RTT',      dest='tu',        help='RTT ',                                   default=0.01, required=False,type=int)
    parser.add_argument('-bs', '--Buf_size', dest='bs',        help='max buffer size ',                       default=10, required=False, type=int)
    parser.add_argument('-p', '--phy',       dest='phy',       help='add if generating physical ini file',    default=0, required=False,type=int)

    options = parser.parse_args(args)
    return options

####################################################################################################


"""
create topo: create the ini file
    input : CCA num, flow num
    output: .ini file for topology 
    isolated topolgy: each algo has its own switch
    base topolgy: one switch - all CCA in the same buffer 

        Client1       Client2
           |             |
      --Switch--     --Switch--
                   |
                 Server
"""
def create_topo(physical, flows,iso,total_bw,tu,bs,error):
    print("*** creating isolation topo cfg ini file, flows for each CCA: {}, Physical:{} ***\n".format(flows,physical))

 

    config = configparser.ConfigParser()
    config["parameters"] = {
        "name"       : "TopoIso",
        "isolation"  : iso,
        "flows_num"  : flows,
        "flows_error": error,
        "servers_num": 1,
        "switches_link_bandwidth": total_bw,
        "RTT": tu,
        "buffer_size": bs,
    }

    if(not physical):
        config["ips"] = {
            "server_base_ip" : "192.168.1.",
            "client_base_ip" : "192.168.1."
        }
    else:
        config["ips"] = {
            "server_base_ip" : "10.72.1.",
            "client_base_ip" : "10.72.1."
        }

    config["ports"] = {
        "server_base_port" : "5001",
        "client_base_port" : "7001"
    }



    if(not physical):
        with open("cfg/Topo1_cfg.ini", "w") as topo1_config_file:
            config.write(topo1_config_file)
    else:
        with open("cfg/Topo1_cfg_phy.ini", "w") as topo1_config_file:
            config.write(topo1_config_file)

####################################################################################################

if __name__ == '__main__':
    options = get_options()
    create_topo(options.phy,options.flow_num,options.isolution,options.total_bw,options.tu,options.bs,options.error)
