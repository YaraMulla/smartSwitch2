#!/usr/bin/python

import configparser
import argparse
import sys
import mininet
import ast
from mininet.node import Node
from mininet.link import TCLink
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.log import setLogLevel, info
from mininet.cli import CLI
import subprocess
import time 

####################################################################################################
def arg_parser():
    parser = argparse.ArgumentParser(description="netTopology: generate a network topology and run a traffic on it")
    parser.add_argument("-topo",   type=str, required=True, dest="topo_cfg_file",   help="path to topo ini file")
    parser.add_argument("-iperf3", type=str, required=True, dest="iperf3_cfg_file", help="path to iperf3 ini file")
    #parser.add_argument("-bw_cfg", type=str, required=True, dest="bw_cfg",          help="BW CFG")
    #parser.add_argument("-sc"    , type=str, required=True, dest="sc",              help="scenario number")
    args = parser.parse_args()
    print('{}\n'.format(args))
    return args

####################################################################################################
class NetworkTopo(Topo):
    """ Custom Network Topology"""
    def __init__(self, **opts):
        super(NetworkTopo, self).__init__(**opts)
        
        topo_cfg = configparser.ConfigParser()
        topo_cfg.read(opts["topo_cfg_file"])
        iperf3_cfg = configparser.ConfigParser()
        iperf3_cfg.read(opts["iperf3_cfg_file"])
        
        cca      = int(iperf3_cfg["parameters"]["reno"])+ int(iperf3_cfg["parameters"]["vegas"])+ int(iperf3_cfg["parameters"]["bbr"])+ int(iperf3_cfg["parameters"]["cubic"])
        iso      = int(topo_cfg["parameters"]["isolation"])
        flows    = int(topo_cfg["parameters"]["flows_num"])
        if iso==0:
            switches=1
        else:
            switches=cca
        bw       = float(topo_cfg["parameters"]["switches_link_bandwidth"])
        tu       = topo_cfg["parameters"]["RTT"]
        bs       = int(topo_cfg["parameters"]["buffer_size"])

        print("*** building the network ***\n")
        sw0 = self.addSwitch("sw0")
        server = self.addHost(name="server" , ip=(topo_cfg["ips"]["server_base_ip"] + str(100) + '/24'))
       
        
        buffer_size = bs #TODO function
        unwanted_delay=0
        unlimited_buffer=1
        unlimited_bw=0.12#1000 one package per o.1 sec
        
        sw1 = self.addSwitch("sw1")
        self.addLink(sw1, sw0, cls=TCLink, bw=bw, max_queue_size=buffer_size,enable_ecn=False,enable_red=False)
        
        self.addLink(sw0, server,cls=TCLink, delay=tu)
        for i in range(cca):
            for j in range(flows):
                client_num=i*flows+j
                new_client = self.addHost(name=("client_" + str(client_num)),ip=(topo_cfg["ips"]["client_base_ip"] + str(client_num + 1+64*i) + '/24'))
                self.addLink(new_client, sw1, cls=TCLink, delay=tu,enable_ecn=False,enable_red=False)
        
        
        
        
       # if iso==0:
       #     sw1 = self.addSwitch("sw1")
       #     self.addLink(sw1, sw0, cls=TCLink, delay=tu,max_queue_size=buffer_size)
       #     for i in range(cca*flows):
       #         new_client = self.addHost(name=("client_" + str(i)),ip=(topo_cfg["ips"]["client_base_ip"] + str(i + 1) + '/24'))
       #         self.addLink(new_client, sw1, cls=TCLink,delay=tu,enable_ecn=False,enable_red=False)

                
       # #self.addLink(s1,s2,cls=TCLink,bw=bw,delay=,max_queue_size, use_tbf=)
       # else:
       #     for i in range(cca):
       #         sw_cca=self.addSwitch("sw"+str(i+1))
       #         bw_cca = bw/cca#TODO function
       #         buffer_size =bs#/cca#TODO function
       #         print("buffer size = " +str(buffer_size)+ " delay is "+str(tu))
       #         self.addLink(sw_cca, sw0, cls=TCLink, delay=tu,enable_ecn=False,enable_red=False)#, max_queue_size=buffer_size)
       #         for j in range(flows):
       #             client_num=i*flows+j
       #             new_client = self.addHost(name=("client_" + str(client_num)),ip=(topo_cfg["ips"]["client_base_ip"] + str(client_num + 1+64*i) + '/24'))
       #             self.addLink(new_client, sw_cca, cls=TCLink, delay=tu,enable_ecn=False,enable_red=False)

####################################################################################################
#input CCA, n-num of flow, RTT, c-link capacity

class SimpleNetwork(Topo):
    def __init__(self, **opts):
        super(SimpleNetwork, self).__init__(**opts)
        
        topo_cfg = configparser.ConfigParser()
        topo_cfg.read(opts["topo_cfg_file"])
        
        bw       = float(topo_cfg["parameters"]["switches_link_bandwidth"])
        tu       = topo_cfg["parameters"]["RTT"]
        bs       = int(topo_cfg["parameters"]["buffer_size"])
        for b in range(bs):
            print("buffer size = " +str(b)+ " delay is "+str(tu), " bw = " +str(bw))
            reno_server = self.addHost(name=("server_"+str(b)) , ip=(topo_cfg["ips"]["server_base_ip"] + str(100+b) + '/24'))
            sw_reno=self.addSwitch("sw"+str(b))
            new_reno_client = self.addHost(name=("client_"+str(b)),ip=(topo_cfg["ips"]["client_base_ip"] + str(1+b) + '/24'))
            self.addLink(new_reno_client,sw_reno ,cls=TCLink)#"100ms"
            self.addLink(sw_reno, reno_server, cls=TCLink, bw=bw, delay=tu, max_queue_size=b+1, txo=False, rxo=False, use_hfsc=False, use_tbf=False,enable_ecn=False,enable_red=False)
            
            vegas_server = self.addHost(name=("server_"+str(bs+b)) , ip=(topo_cfg["ips"]["server_base_ip"] + str(100+b+bs) + '/24'))
            new_vegas_client = self.addHost(name=("client_"+str(bs+b)),ip=(topo_cfg["ips"]["client_base_ip"] + str(1+b+bs) + '/24'))
            sw_vegas=self.addSwitch("sw"+str(b+bs))
            self.addLink(new_vegas_client,sw_vegas, cls=TCLink)                           
            self.addLink(sw_vegas,vegas_server, cls=TCLink, bw=bw, delay=tu, max_queue_size=b+1, txo=False, rxo=False, use_hfsc=False, use_tbf=False,enable_ecn=False,enable_red=False)


class TestNetwork(Topo):
    def __init__(self, **opts):
        super( TestNetwork, self).__init__(**opts)
        
        topo_cfg = configparser.ConfigParser()
        topo_cfg.read(opts["topo_cfg_file"])
        
        bw       = float(topo_cfg["parameters"]["switches_link_bandwidth"])
        tu       = topo_cfg["parameters"]["RTT"]
        bs       = int(topo_cfg["parameters"]["buffer_size"])
        
   
        server = self.addHost(name=("server") , ip=(topo_cfg["ips"]["server_base_ip"] + str(100) + '/24'))
        
        new_reno_client = self.addHost(name=("client_"+str(0)),ip=(topo_cfg["ips"]["client_base_ip"] + str(1) + '/24'))
        new_vegas_client = self.addHost(name=("client_"+str(1)),ip=(topo_cfg["ips"]["client_base_ip"] + str(2) + '/24'))
                              
        sw0=self.addSwitch("sw"+str(0))
        sw1=self.addSwitch("sw"+str(1))
        
        self.addLink(new_reno_client,sw0 ,cls=TCLink)#"100ms"
        self.addLink(new_vegas_client,sw0, cls=TCLink)                    
        self.addLink(sw0, sw1 ,cls=TCLink, bw=bw,  delay=tu)               
        self.addLink(sw1, server, cls=TCLink)
            
def run(args):

    iperf3_cfg = configparser.ConfigParser()
    iperf3_cfg.read(args.iperf3_cfg_file)

    topo_cfg = configparser.ConfigParser()
    topo_cfg.read(args.topo_cfg_file)

    topo = NetworkTopo(topo_cfg_file=args.topo_cfg_file, iperf3_cfg_file=args.iperf3_cfg_file)
    #topo = SimpleNetwork(topo_cfg_file=args.topo_cfg_file, iperf3_cfg_file=args.iperf3_cfg_file)
    #topo = TestNetwork(topo_cfg_file=args.topo_cfg_file, iperf3_cfg_file=args.iperf3_cfg_file)
    
    net = Mininet(topo=topo,link=TCLink)
    net.start()
    iso      = int(topo_cfg["parameters"]["isolation"])
    sc_dict = ast.literal_eval(iperf3_cfg["sc"]["1"])
    active_clients_num = len(sc_dict["clients_cmds"].keys())
    client_transmit_time = iperf3_cfg["parameters"]["transmit_time"]
    dc =int(iperf3_cfg["parameters"]["direct_connection"])
    sleep_time = int(client_transmit_time) *2

    traffic_generator = open("genTraffic.sh","w")
    print("***generating genTraffic.sh***\n")
    #sleep = 0.2
    server_name = "server "
    print("***one server is receiving***")
    print("***"+str(active_clients_num)+" clients are sending***\n")
    
   # traffic_generator.write("iptables -t mangle -A PREROUTING -i sw0-eth1 -j MARK --set-mark 2 \n")
   # traffic_generator.write("iptables -t mangle -A PREROUTING -i sw0-eth2 -j MARK --set-mark 3 \n")
    
    sw = net['sw0']

    ##sw.cmd('iptables -t mangle -A PREROUTING -i eth1 -j MARK --set-mark 2')
    ##sw.cmd('iptables -t mangle -A PREROUTING -i eth2 -j MARK --set-mark 3')

    ##sw.cmd('tc qdisc add dev sw0-eth1 root htb rate 0.143mbit')
    
    ##add classes
    sw.cmd('tc class add dev sw0-eth1 parent 5:0 classid 5:2 htb rate 0.143mbit quantum 1599')
    sw.cmd('tc class add dev sw0-eth1 parent 5:0 classid 5:3 htb rate 0.143mbit quantum 1599')
    sw.cmd('tc class add dev sw0-eth1 parent 5:0 classid 5:4 htb rate 0.143mbit quantum 1599')
    sw.cmd('tc class add dev sw0-eth1 parent 5:0 classid 5:5 htb rate 0.143mbit quantum 1599')
    
    ##sw.cmd('tc class add dev sw0-eth3 parent 5:2 handle 20: tbf rate 20kbit buffer 1600 limit 3000')

    sw.cmd('tc qdisc add dev sw0-eth1 parent 5:2 handle 20: netem limit 10')
    sw.cmd('tc qdisc add dev sw0-eth1 parent 5:3 handle 30: netem limit 10')
    sw.cmd('tc qdisc add dev sw0-eth1 parent 5:4 handle 40: netem limit 10')
    sw.cmd('tc qdisc add dev sw0-eth1 parent 5:5 handle 50: netem limit 10')
    #sw.cmd('tc qdisc add dev sw0-eth1 parent 5:1 handle 10: netem limit 10 delay 10ms')#tbf rate 0.143mbit limit 1600 buffer 1600')# tbf rate 0.143mbit limit 3')
    if iso==1:
        ##add filters
        sw.cmd('tc filter add dev sw0-eth1 protocol ip parent 5:0 u32 match ip src 192.168.1.1/26 flowid 5:2')
        sw.cmd('tc filter add dev sw0-eth1 protocol ip parent 5:0 u32 match ip src 192.168.1.64/26 flowid 5:3')
        sw.cmd('tc filter add dev sw0-eth1 protocol ip parent 5:0 u32 match ip src 192.168.1.128/26 flowid 5:4')
        sw.cmd('tc filter add dev sw0-eth1 protocol ip parent 5:0 u32 match ip src 192.168.1.192/26 flowid 5:5')
    
    ##dport 5002 0xffff flowid 5:3')
    
    sw.cmd('/usr/sbin/sshd')

    
    ##traffic_generator.write("tc class add dev sw0-eth3 parent 5: classid 5:2 htb rate 1000mbit \n")
    ##traffic_generator.write("tc class add dev sw0-eth3 parent 5: classid 5:3 htb rate 1000mbit \n")
    ##ethtool -K client_0-eth0 tso off
    for i in range(active_clients_num):
        traffic_generator.write("client_"+str(i)+" ethtool -K client_"+str(i)+"-eth0 tso off"+ "\n")
    for i in range(active_clients_num):
        if dc==0:
            server_name = "server "
        else:
            server_name = "server_"+str(i)+" "
            
        traffic_generator.write(server_name + sc_dict["server_cmds"][str(i)] + "\n")
        sniffing_cmd = "tcpdump -n 'tcp port %d' -w %s &" % (int(topo_cfg["ports"]["server_base_port"])+ i, "c"+str(i)+".pcap")
        traffic_generator.write(server_name + sniffing_cmd + "\n")
    for i in range(active_clients_num):
        curr_client='client_'+str(i)+" "
        traffic_generator.write(curr_client + sc_dict["clients_cmds"][str(i)] + "\n")


    traffic_generator.close()
    myScript = "genTraffic.sh"
    print("***running genTraffic***\n")
    CLI(net)
    CLI(net, script=myScript)
    #CLI(net)
    time.sleep(sleep_time)
    net.stop()

############################################################################
def move_files(args):
    topo_cfg = configparser.ConfigParser()
    topo_cfg.read(args.topo_cfg_file)
    
    iso = topo_cfg["parameters"]["isolation"]
    flows = topo_cfg["parameters"]["flows_num"]
    print("***moving logs***\n")
    cmd1 = "mv c*.log ./run/isolation{}".format(iso)
    cmd2 = "mv c*.pcap ./run/isolation{}".format(iso)

    move_log_process = subprocess.Popen(cmd1, stdout=subprocess.PIPE, shell=True)
    move_pcap_process = subprocess.Popen(cmd2, stdout=subprocess.PIPE, shell=True)

############################################################################
if __name__ == '__main__':
    args = arg_parser()
    run(args)
    move_files(args)
