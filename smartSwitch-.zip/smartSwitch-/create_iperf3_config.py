import configparser
import argparse
import sys
import ast
import random
import math

####################################################################################################
"""
get_options
    get user options
    input : argv[1:]
    output: options
"""
def get_options(args=sys.argv[1:]):
    parser = argparse.ArgumentParser(description="Parse user input")
    parser.add_argument("-topo", "--topo", type=str, required=True, help="topology init file")
    parser.add_argument("-t", "--transmit_time", dest ='transmit_time', type=int, default=80, required=False, help="transmit time in iperf3")
    parser.add_argument("-d", "--direct_connection", dest='dc', action='store_const', const=1, default=0, required=False, help="give each client server") 
    parser.add_argument("-reno", "--R", dest='reno', action='store_const', const=1, default=0, required=False, help="run with reno CCA")
    parser.add_argument("-vegas","--V", dest='vegas', action='store_const', const=1, default=0, required=False, help="run with vegas CCA")
    parser.add_argument("-bbr",  "--B", dest='bbr', action='store_const', const=1,  default=0, required=False, help="run with bbr CCA")
    parser.add_argument("-cubic","--C", dest='cubic', action='store_const', const=1, default=0, required=False, help="run with cubic CCA")
    
    options = parser.parse_args(args)
    return options


####################################################################################################
"""
final state return the final state matrix depend on F1
"""
def final_state(f1):
    r1 = math.sqrt(1/1.1)
    r2 = math.sqrt(1/40)
    m=1/3

    s=2*(1+r1+r2)
    a=(3*m-f1)/s

    a2=a
    a3=r1*a
    a4=r2*a

    final = [[3*(m-2*a), 3*a, 3*a],
             [3*a3, 3*(m-2*a3), 3*a3],
             [3*a4, 3*a4, 3*(m-2*a4)]]
    return final



####################################################################################################
"""
create_iperf3_ini : create the iperf3 ini files for topology
    input : topo_init_file , transmit_time (each client transmit time to server), with which CCA we run 
    output: iperf3 ini file for topology1
"""
def create_iperf3_ini(topo_init_file, transmit_time, dc, reno, vegas, bbr, cubic):

    topo_config = configparser.ConfigParser()
    topo_config.read(topo_init_file)
    iperf3_config = configparser.ConfigParser()

    parameters_hash = {}
    server_cmd_hash = {}
    client_cmd_hash = {}
    sc_hash = {}
    ip_addr = {}

    print("*** creating iperf3 cfg file for {}, scenario - all clients are sending\n".format(topo_config["parameters"]["name"]))
    iperf3_config["parameters"] = {
        "name": topo_config["parameters"]["name"],
        "transmit_time": transmit_time,
        "direct_connection": dc,
        "Reno" : reno,
        "Cubic": cubic,
        "BBR"  : bbr,
        "Vegas": vegas,  
    }
    server_ip = topo_config["ips"]["server_base_ip"] #str(100)
    server_base_port = topo_config["ports"]["server_base_port"]
    # Create iperf3 config file for Topo1 and Topo2 (scenario1 - all clients are sending)
    flow_num = int(topo_config["parameters"]["flows_num"])
    error=int(topo_config["parameters"]["flows_error"])
    if dc==0:
        cmd_num = flow_num*(reno+vegas+bbr+cubic)+error*(reno+vegas+bbr+cubic-1)*(reno+vegas+bbr+cubic)
    else:
        bs=int(topo_config["parameters"]["buffer_size"])
        cmd_num = (reno+vegas+bbr+cubic)*bs

    print("******** command num is:"+ str(cmd_num))
    cmd = 0
    cca_list = []

    if reno:
        cca_list.append("reno")
    if cubic:
        cca_list.append("cubic")
    if bbr:
        cca_list.append("bbr")    
    if vegas:
        cca_list.append("vegas")
    
    #p=[0.1, 0.1, 0.8]
    #print("random num "+str(random.choices(range(1,4),p)))

    final=final_state(1)
    reno_p  = final[0]
    cubic_p = final[1]
    bbr_p   = final[2]
    #print("final state"+str(final[1]))
  

    
    #if reno:
    #    cca_list.append("reno")
    #    for f in range(flow_num):
    #        c="reno"
    #        server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
    #        client_cmd_hash[str(cmd)] = "iperf3 -i 1 -V -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (server_ip, str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(cmd+1),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+".log")
    #        cmd = cmd +1 
        
    #if vegas:
    #    cca_list.append("vegas")
    #    for f in range(flow_num):
    #        c="vegas"
    #        server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
    #        client_cmd_hash[str(cmd)] = "iperf3 -i 1 -V -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (server_ip, str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(cmd+1+64),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+".log")
    #        cmd = cmd +1
    #if bbr:
    #    cca_list.append("bbr")
    #    for f in range(flow_num):
    #        c="bbr"
    #        server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
    #        client_cmd_hash[str(cmd)] = "iperf3 -i 1 -V -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (server_ip, str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(cmd+1+128),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+".log")
    #        cmd = cmd +1
    #if cubic:
    #    cca_list.append("cubic")
    #    for f in range(flow_num):
    #        c="cubic"
    #        server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
    #        client_cmd_hash[str(cmd)] = "iperf3 -i 1 -V -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (server_ip, str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(cmd+1+192),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+".log")
    #        cmd = cmd +1


    '''
    # -i for interval time parameter report
    # -s server, -c client
    # -p port to listen (same in server and client)
    #-C set congestion control algorithm'''

    
    #bw=120000 #one packet per 0.1 
    #cmd = 0
    #if dc==0:
    #    print("flows "+str(flow_num))
    base_ip=0
    base_ip_array=[8,10,14]#[0,64,128]
    cca_num=0
    #print(str(final))
    #print(str(final[0]))
    for c in cca_list:
        for f in range(flow_num-error):
            
            #server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
            server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "server.log")
            p=final[cca_num]
            base_ip=random.choices(base_ip_array,p)[0]
            if(cmd<254):
                ip_addr[str(cmd)]=str(base_ip)+"."+str(cmd+1)
            else:
                ip_addr[str(cmd)]=str(base_ip+1)+"."+str(cmd+1-254) 
            #trans_algo=random.choices([0, 1, 2],p)[0]
            client_cmd_hash[str(cmd)] = "iperf3 -i 1 -V -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (server_ip, str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(ip_addr[str(cmd)]),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+".log")
           
            cmd=cmd+1
        cca_num=cca_num+1
        #when we have const known error
        for f in range(error):
            for c in cca_list:
                server_cmd_hash[str(cmd)] = "iperf3 -i 1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
                client_cmd_hash[str(cmd)] = "iperf3 -i 1 -V -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (server_ip, str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(cmd+1+base_ip),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+"_error.log")
                cmd=cmd+1

        #in case we do not have probability 
        #base_ip=base_ip+64
            
    #else:
    #    for c in cca_list:
    #        for f in range(bs):
    #            server_ip_dc =topo_config["ips"]["server_base_ip"]+str(100+cmd)
    #            server_cmd_hash[str(cmd)] = "iperf3 -i 0.1 -s -p %s > %s &" % (str(cmd + int(topo_config["ports"]['server_base_port'])), "client" + str(cmd) + "_server.log")
    #            client_cmd_hash[str(cmd)] = "iperf3 -i 0.1 -V -O 30 -c %s -p %s -C %s -t %s -B %s --cport %s > %s &" % (str(server_ip_dc), str(cmd + int(topo_config["ports"]['server_base_port'])),str(c), str(transmit_time), topo_config["ips"]["client_base_ip"]+str(cmd+1),str(cmd + int(topo_config["ports"]['client_base_port'])), "client"+str(cmd) +"_"+str(c)+".log")
    #            cmd=cmd+1
                


    sc_hash["1"] = {
        "server_cmds"   : server_cmd_hash,
        "clients_cmds"  : client_cmd_hash,
        "ip_addr"       : ip_addr
                   }
    iperf3_config["sc"] = sc_hash

    with open("cfg/iperf3.ini", "w") as iperf3_config_file:
        iperf3_config.write(iperf3_config_file)

####################################################################################################
if __name__ == "__main__":
    options = get_options()
    create_iperf3_ini(options.topo, options.transmit_time,options.dc ,options.reno, options.vegas, options.bbr, options.cubic)
